﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","es-mx",{button:"Insertar fragmento de código",codeContents:"Contenido del código",emptySnippetError:"Un fragmento de código no puede estar vacio.",language:"Idioma",title:"Fragmento de código",pathName:"fragmento de código"});
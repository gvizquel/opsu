﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","fi",{title:"Käyttöliittymän väripaletti",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Esimääritellyt värijoukot",config:"Liitä tämä merkkijono config.js tiedostoosi"});